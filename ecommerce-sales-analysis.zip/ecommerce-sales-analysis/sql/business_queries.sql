-- ============================================================
-- E-Commerce Sales Analysis – Business SQL Queries
-- Database: SQLite  |  Run via: eda_notebook.py or DB Browser
-- ============================================================

-- ── 1. Total revenue by category ─────────────────────────────
SELECT
    oi.category,
    COUNT(DISTINCT o.order_id) AS total_orders,
    SUM(oi.total_price)        AS total_revenue,
    ROUND(AVG(oi.unit_price), 2) AS avg_unit_price
FROM order_items oi
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Delivered'
GROUP BY oi.category
ORDER BY total_revenue DESC;


-- ── 2. Monthly revenue trend ──────────────────────────────────
SELECT
    strftime('%Y-%m', o.order_date) AS month,
    COUNT(DISTINCT o.order_id)      AS orders,
    SUM(oi.total_price)             AS revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status = 'Delivered'
GROUP BY month
ORDER BY month;


-- ── 3. Top 10 customers by lifetime value ─────────────────────
SELECT
    o.customer_id,
    c.city,
    c.state,
    COUNT(DISTINCT o.order_id)    AS total_orders,
    SUM(oi.total_price)           AS lifetime_value,
    ROUND(AVG(oi.total_price), 2) AS avg_order_value
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN customers  c  ON o.customer_id = c.customer_id
WHERE o.status = 'Delivered'
GROUP BY o.customer_id
ORDER BY lifetime_value DESC
LIMIT 10;


-- ── 4. Revenue & orders by state ──────────────────────────────
SELECT
    c.state,
    COUNT(DISTINCT o.order_id) AS total_orders,
    COUNT(DISTINCT o.customer_id) AS unique_customers,
    ROUND(SUM(oi.total_price), 2) AS total_revenue
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN customers  c  ON o.customer_id = c.customer_id
WHERE o.status = 'Delivered'
GROUP BY c.state
ORDER BY total_revenue DESC;


-- ── 5. Order status breakdown (%) ────────────────────────────
SELECT
    status,
    COUNT(DISTINCT order_id) AS order_count,
    ROUND(
        COUNT(DISTINCT order_id) * 100.0 / (SELECT COUNT(*) FROM orders),
        2
    ) AS percentage
FROM orders
GROUP BY status
ORDER BY order_count DESC;


-- ── 6. Top 10 best-selling products ──────────────────────────
SELECT
    oi.product_name,
    oi.category,
    SUM(oi.quantity)   AS units_sold,
    SUM(oi.total_price) AS revenue
FROM order_items oi
JOIN orders o ON oi.order_id = o.order_id
WHERE o.status = 'Delivered'
GROUP BY oi.product_name, oi.category
ORDER BY revenue DESC
LIMIT 10;


-- ── 7. Average order value by category ───────────────────────
SELECT
    category,
    ROUND(AVG(order_total), 2) AS avg_order_value
FROM (
    SELECT oi.category,
           oi.order_id,
           SUM(oi.total_price) AS order_total
    FROM order_items oi
    JOIN orders o ON oi.order_id = o.order_id
    WHERE o.status = 'Delivered'
    GROUP BY oi.order_id, oi.category
) sub
GROUP BY category
ORDER BY avg_order_value DESC;


-- ── 8. Repeat vs one-time buyers ─────────────────────────────
SELECT
    CASE WHEN order_count = 1 THEN 'One-time Buyer'
         ELSE 'Repeat Buyer' END AS customer_type,
    COUNT(*) AS customer_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(DISTINCT customer_id) FROM orders), 2) AS pct
FROM (
    SELECT customer_id, COUNT(DISTINCT order_id) AS order_count
    FROM orders
    WHERE status = 'Delivered'
    GROUP BY customer_id
) sub
GROUP BY customer_type;


-- ── 9. Peak sales hours (day of week) ────────────────────────
SELECT
    CASE strftime('%w', order_date)
        WHEN '0' THEN 'Sunday'    WHEN '1' THEN 'Monday'
        WHEN '2' THEN 'Tuesday'   WHEN '3' THEN 'Wednesday'
        WHEN '4' THEN 'Thursday'  WHEN '5' THEN 'Friday'
        WHEN '6' THEN 'Saturday'
    END AS day_of_week,
    COUNT(DISTINCT order_id) AS total_orders
FROM orders
WHERE status = 'Delivered'
GROUP BY strftime('%w', order_date)
ORDER BY total_orders DESC;


-- ── 10. Year-over-year revenue comparison ────────────────────
SELECT
    strftime('%Y', o.order_date) AS year,
    SUM(oi.total_price)          AS total_revenue,
    COUNT(DISTINCT o.order_id)   AS total_orders
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
WHERE o.status = 'Delivered'
GROUP BY year
ORDER BY year;
