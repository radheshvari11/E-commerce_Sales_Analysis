# 🛒 E-Commerce Sales Analytics Dashboard

An end-to-end data analysis project built with Python, Pandas, SQL, and Streamlit.
Explores sales trends, customer behavior, and product performance across 5,000+ orders.

---

## 📊 Features

- **KPI Metrics** — Total Revenue, Orders, Avg Order Value, Unique Customers
- **Revenue Over Time** — Monthly trend line chart with seasonal patterns
- **Category Analysis** — Donut chart of sales by product category
- **Top 10 Products** — Best-selling products by revenue
- **Order Status Breakdown** — Delivered, Shipped, Cancelled, Returned
- **Geographic Analysis** — Revenue heatmap by US state
- **Sales Heatmap** — Month × Year revenue patterns
- **Interactive Filters** — Filter by date, category, order status, and state

---

## 🗂️ Project Structure

```
ecommerce-sales-analysis/
├── app.py                  # Streamlit dashboard (main app)
├── generate_data.py        # Sample data generator
├── eda_analysis.py         # Exploratory Data Analysis script
├── requirements.txt        # Python dependencies
├── data/                   # Auto-generated CSV files
│   ├── customers.csv
│   ├── products.csv
│   ├── orders.csv
│   └── order_items.csv
├── sql/
│   └── business_queries.sql  # 10 SQL business questions
└── outputs/                  # EDA charts (auto-generated)
```

---

## 🛠️ Tech Stack

| Tool | Purpose |
|------|---------|
| Python 3.12 | Core language |
| Pandas | Data manipulation & EDA |
| NumPy | Numerical operations |
| Plotly | Interactive charts |
| Streamlit | Web dashboard |
| Matplotlib / Seaborn | EDA visualizations |
| SQLite3 | SQL queries on in-memory DB |

---

## 🚀 How to Run

### 1. Clone the repository
```bash
git clone https://github.com/YOUR_USERNAME/ecommerce-sales-analysis.git
cd ecommerce-sales-analysis
```

### 2. Create a virtual environment
```bash
py -3.12 -m venv venv
venv\Scripts\activate
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Generate sample data
```bash
python generate_data.py
```

### 5. Run EDA analysis (optional)
```bash
python eda_analysis.py
```

### 6. Launch the dashboard
```bash
streamlit run app.py
```

Open your browser at **http://localhost:8501**

---

## 📈 Key Insights from the Data

- 📦 **62%** of all orders are successfully delivered
- 🎄 **November & December** show peak sales (seasonal trend)
- 💻 **Electronics** is the highest revenue category
- 🗺️ **California, Texas & New York** are the top 3 states by revenue
- 🔁 Majority of customers are **repeat buyers**

---

## 🧠 Skills Demonstrated

- Exploratory Data Analysis (EDA)
- Data cleaning & transformation with Pandas
- SQL queries (JOINs, CTEs, window functions, aggregations)
- Interactive dashboard development with Streamlit
- Data visualization with Plotly, Matplotlib & Seaborn
- Python project structuring for GitHub

---

## 👩‍💻 Author

**Sakshi**  
Aspiring Data Analyst | Python · SQL · Streamlit · Machine Learning  
[GitHub](https://github.com/YOUR_USERNAME) · [LinkedIn](https://linkedin.com/in/YOUR_PROFILE)
